const photoArea = document.getElementById('photoArea');
const textArea = document.getElementById('textArea');
const secretBtn = document.getElementById('secretBtn');
const adminModal = document.getElementById('adminModal');
const closeAdmin = document.getElementById('closeAdmin');
const loginBox = document.getElementById('loginBox');
const loginBtn = document.getElementById('loginBtn');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const editor = document.getElementById('editor');
const fileInput = document.getElementById('fileInput');
const preview = document.getElementById('preview');
const editText = document.getElementById('editText');
const saveBtn = document.getElementById('saveBtn');
const logoutBtn = document.getElementById('logoutBtn');
const loginMsg = document.getElementById('loginMsg');

let isAdmin = false;
let currentData = null;
let pendingImageDataUrl = null;

async function load() {
  try {
    const res = await fetch('/api/getData');
    const j = await res.json();
    currentData = j;
    render();
  } catch (e) {
    textArea.textContent = '無法載入資料';
  }
}

function render() {
  if (currentData && currentData.photo) {
    photoArea.innerHTML = '<img src="'+currentData.photo+'" alt="聯絡簿照片">';
  } else {
    photoArea.innerHTML = '<div class="small">尚未上傳照片</div>';
  }
  textArea.textContent = currentData && currentData.text ? currentData.text : '今日尚未填寫聯絡簿';
}

secretBtn.addEventListener('click', ()=>{
  adminModal.setAttribute('aria-hidden','false');
});

closeAdmin.addEventListener('click', ()=>{
  adminModal.setAttribute('aria-hidden','true');
  resetAdmin();
});

function resetAdmin(){
  loginBox.style.display = 'block';
  editor.style.display = 'none';
  loginMsg.textContent = '';
  usernameInput.value = '';
  passwordInput.value = '';
  preview.innerHTML = '';
  editText.value = currentData ? currentData.text : '';
  pendingImageDataUrl = null;
}

loginBtn.addEventListener('click', async ()=>{
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();
  const res = await fetch('/api/login', {
    method: 'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({username,password})
  });
  const j = await res.json();
  if (j.success) {
    isAdmin = true;
    loginBox.style.display = 'none';
    editor.style.display = 'block';
    editText.value = currentData.text || '';
    loginMsg.textContent = '登入成功，請編輯後按儲存。';
  } else {
    loginMsg.textContent = '登入失敗，請確認帳密。';
  }
});

fileInput.addEventListener('change', ()=>{
  const f = fileInput.files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = ()=>{
    pendingImageDataUrl = reader.result;
    preview.innerHTML = '<img src="'+pendingImageDataUrl+'">';
  };
  reader.readAsDataURL(f);
});

saveBtn.addEventListener('click', async ()=>{
  const content = editText.value;
  const payload = { text: content, photo: pendingImageDataUrl || (currentData && currentData.photo) || '' };
  const res = await fetch('/api/updateData', {
    method: 'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  });
  const j = await res.json();
  if (j.success) {
    currentData = payload;
    render();
    alert('已儲存');
    adminModal.setAttribute('aria-hidden','true');
    resetAdmin();
  } else {
    alert('儲存失敗');
  }
});

logoutBtn.addEventListener('click', ()=>{
  isAdmin = false;
  adminModal.setAttribute('aria-hidden','true');
  resetAdmin();
});

load();