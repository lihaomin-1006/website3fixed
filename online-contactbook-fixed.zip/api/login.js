module.exports = (req, res) => {
  const body = req.body || {};
  const username = body.username;
  const password = body.password;
  const ADMIN_USER = 'admin';
  const ADMIN_PASS = '123456';
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    return res.status(200).json({ success: true });
  }
  return res.status(200).json({ success: false });
};
