const fs = require('fs');
const path = require('path');

module.exports = (req, res) => {
  const dataFile = path.join(process.cwd(), 'data.json');
  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify({photo:'', text:''}, null, 2));
  }
  const data = JSON.parse(fs.readFileSync(dataFile,'utf8'));
  res.status(200).json(data);
};
