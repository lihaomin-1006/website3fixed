const fs = require('fs');
const path = require('path');

module.exports = (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, message: 'Method not allowed' });
  }
  const body = req.body || {};
  const text = body.text || '';
  const photo = body.photo || '';
  const dataFile = path.join(process.cwd(), 'data.json');
  const data = { text: text, photo: photo };
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
  res.status(200).json({ success: true });
};
